package edu.ycp.cs320.otterspace.controller;

import edu.ycp.cs320.otterspace.model.GameModel;

public class GameController 
{
	private GameModel model;
	
	public void setModel(GameModel model)
	{
		this.model = model;
	}
}
